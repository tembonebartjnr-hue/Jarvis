package com.example.jarvis
import android.content.Context
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Tasks
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Mail(val id: String, val from: String, val subject: String, val snippet: String)

/** Read-only Gmail access via Google's official authorization (cannot send or delete mail). */
object Gmail {
  fun request(): AuthorizationRequest = AuthorizationRequest.builder()
    .setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/gmail.readonly"))).build()

  // null = user hasn't granted access yet (needs the app's "Connect Gmail" button)
  private fun token(c: Context): String? {
    val r = Tasks.await(Identity.getAuthorizationClient(c).authorize(request()))
    return if (r.hasResolution()) null else r.accessToken
  }
  private fun get(u: String, t: String): JSONObject {
    val c = URL(u).openConnection() as HttpURLConnection
    c.setRequestProperty("Authorization", "Bearer $t"); c.connectTimeout = 10000; c.readTimeout = 15000
    return JSONObject(c.inputStream.bufferedReader().readText())
  }
  fun unread(c: Context, max: Int = 5): List<Mail>? {
    val t = (try { token(c) } catch (e: Exception) { null }) ?: return null
    val q = URLEncoder.encode("is:unread category:primary", "UTF-8")
    val a = get("https://gmail.googleapis.com/gmail/v1/users/me/messages?q=$q&maxResults=$max", t).optJSONArray("messages") ?: return emptyList()
    return (0 until a.length()).map { i ->
      val id = a.getJSONObject(i).getString("id")
      val d = get("https://gmail.googleapis.com/gmail/v1/users/me/messages/$id?format=metadata&metadataHeaders=From&metadataHeaders=Subject", t)
      val hs = d.getJSONObject("payload").getJSONArray("headers")
      fun h(n: String): String { for (j in 0 until hs.length()) if (hs.getJSONObject(j).getString("name") == n) return hs.getJSONObject(j).getString("value"); return "" }
      Mail(id, h("From").replace(Regex("<.*>"), "").replace("\"", "").trim(), h("Subject"), d.optString("snippet"))
    }
  }
}
