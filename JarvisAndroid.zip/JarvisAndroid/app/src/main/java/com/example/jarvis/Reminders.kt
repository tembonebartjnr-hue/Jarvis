package com.example.jarvis
import android.app.*
import android.content.*
import org.json.*
import java.text.SimpleDateFormat
import java.util.*

object Reminders {
  private fun prefs(c: Context) = c.getSharedPreferences("jarvis", 0)
  private fun load(c: Context) = JSONArray(prefs(c).getString("rems", "[]"))
  private fun save(c: Context, a: JSONArray) = prefs(c).edit().putString("rems", a.toString()).apply()

  fun fmt(t: Long): String = SimpleDateFormat("EEEE d MMMM 'at' h:mm a", Locale.UK).format(Date(t))

  fun add(c: Context, text: String, t: Long) {
    val id = System.currentTimeMillis()
    save(c, load(c).put(JSONObject().put("id", id).put("text", text).put("t", t)))
    schedule(c, id, text, t)
  }

  fun pending(c: Context): List<Pair<String, Long>> {
    val a = load(c); val now = System.currentTimeMillis()
    return (0 until a.length()).map { a.getJSONObject(it) }.filter { it.getLong("t") > now }
      .sortedBy { it.getLong("t") }.map { it.getString("text") to it.getLong("t") }
  }

  fun remove(c: Context, id: Long) {
    val a = load(c); val out = JSONArray()
    for (i in 0 until a.length()) if (a.getJSONObject(i).getLong("id") != id) out.put(a.getJSONObject(i))
    save(c, out)
  }

  fun clearAll(c: Context) {
    val a = load(c); val am = c.getSystemService(AlarmManager::class.java)
    for (i in 0 until a.length()) am.cancel(pi(c, a.getJSONObject(i).getLong("id"), ""))
    save(c, JSONArray())
  }

  private fun pi(c: Context, id: Long, text: String) = PendingIntent.getBroadcast(c, id.toInt(),
    Intent(c, ReminderReceiver::class.java).putExtra("t", text).putExtra("id", id), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

  fun schedule(c: Context, id: Long, text: String, t: Long) {
    val am = c.getSystemService(AlarmManager::class.java)
    if (android.os.Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi(c, id, text))
    else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi(c, id, text))   // approximate if exact-alarm permission is off
  }

  fun rescheduleAll(c: Context) {
    val a = load(c); val now = System.currentTimeMillis()
    for (i in 0 until a.length()) a.getJSONObject(i).let { if (it.getLong("t") > now) schedule(c, it.getLong("id"), it.getString("text"), it.getLong("t")) }
  }

  /** "remind me to call Mum tomorrow at 9am" -> (text, millis). Null if no usable time. */
  fun parse(l: String): Pair<String, Long>? {
    var s = Regex("remind me (?:to |about |of )?(.+)").find(l)?.groupValues?.get(1) ?: return null
    val now = Calendar.getInstance(); val cal = Calendar.getInstance().apply { set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    fun clean(x: String) = x.replace(Regex("\\b(on|at|by|for)\\s*$"), "").replace(Regex("\\s+"), " ").trim()

    Regex("in (\\d+|an?) (minute|hour|day|week)s?").find(s)?.let {
      val n = it.groupValues[1].toIntOrNull() ?: 1
      cal.timeInMillis = now.timeInMillis + n * when (it.groupValues[2]) { "minute" -> 60000L; "hour" -> 3600000L; "day" -> 86400000L; else -> 604800000L }
      return clean(s.replace(it.value, "")) to cal.timeInMillis
    }
    var dayFound = false
    if ("tomorrow" in s) { cal.add(Calendar.DAY_OF_YEAR, 1); dayFound = true; s = s.replace("tomorrow", "") }
    else if (Regex("today|tonight|this evening").containsMatchIn(s)) { dayFound = true; s = s.replace(Regex("today|tonight|this evening"), "") }
    else listOf("sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday").forEachIndexed { i, d ->
      if (!dayFound && d in s) {
        var k = (i + 1) - now.get(Calendar.DAY_OF_WEEK); if (k <= 0) k += 7
        cal.add(Calendar.DAY_OF_YEAR, k); dayFound = true; s = s.replace(d, "")
      }
    }
    val tm = Regex("(?:at )?(\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)").find(s)
    val tm24 = Regex("at (\\d{1,2})(?::(\\d{2}))?").find(s)
    when {
      tm != null -> { var h = tm.groupValues[1].toInt() % 12; if (tm.groupValues[3].startsWith("p")) h += 12
        cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, tm.groupValues[2].toIntOrNull() ?: 0); s = s.replace(tm.value, "") }
      tm24 != null -> { cal.set(Calendar.HOUR_OF_DAY, tm24.groupValues[1].toInt()); cal.set(Calendar.MINUTE, tm24.groupValues[2].toIntOrNull() ?: 0); s = s.replace(tm24.value, "") }
      dayFound -> { cal.set(Calendar.HOUR_OF_DAY, 9); cal.set(Calendar.MINUTE, 0) }   // day only -> 9 AM
      else -> return null
    }
    if (cal.timeInMillis <= now.timeInMillis) return null
    return clean(s) to cal.timeInMillis
  }
}

class ReminderReceiver : BroadcastReceiver() {
  override fun onReceive(c: Context, i: Intent) {
    val nm = c.getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("rem", "Reminders", NotificationManager.IMPORTANCE_HIGH))
    nm.notify(System.nanoTime().toInt(), Notification.Builder(c, "rem").setContentTitle("Jarvis reminder")
      .setContentText(i.getStringExtra("t")).setSmallIcon(android.R.drawable.ic_dialog_info).setAutoCancel(true).build())
    Reminders.remove(c, i.getLongExtra("id", 0))
  }
}

class BootReceiver : BroadcastReceiver() {
  override fun onReceive(c: Context, i: Intent) { Reminders.rescheduleAll(c) }
}
