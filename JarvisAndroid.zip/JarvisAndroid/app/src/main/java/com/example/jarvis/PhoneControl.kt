package com.example.jarvis
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PhoneControl : AccessibilityService() {
  companion object { var instance: PhoneControl? = null }
  override fun onServiceConnected() { instance = this }
  override fun onUnbind(i: android.content.Intent?): Boolean { instance = null; return super.onUnbind(i) }
  override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
  override fun onInterrupt() {}
  fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
  fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
  fun scroll(down: Boolean): Boolean {
    val n = findScrollable(rootInActiveWindow) ?: return false
    return n.performAction(if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
  }
  private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
    if (n == null) return null; if (n.isScrollable) return n
    for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }; return null
  }
  fun tapText(t: String): Boolean {
    var n = rootInActiveWindow?.findAccessibilityNodeInfosByText(t)?.firstOrNull() ?: return false
    while (!n.isClickable) n = n.parent ?: return false
    return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
  }
}
