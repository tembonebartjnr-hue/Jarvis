package com.example.jarvis
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.*
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import ai.picovoice.eagle.*
import com.google.android.gms.auth.api.identity.Identity
import java.io.File

// Picovoice AccessKey is entered in the app (saved on the phone)
fun key(c: android.content.Context): String = c.getSharedPreferences("jarvis", 0).getString("pv", "") ?: ""

class MainActivity : Activity() {
  private lateinit var status: TextView
  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
    status = TextView(this).apply { text = "Jarvis ready"; textSize = 16f }
    fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    setContentView(LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40)
      addView(status)
      val k = EditText(context).apply { hint = "Claude API key (sk-ant-...)"; setText(getSharedPreferences("jarvis", 0).getString("api", "")); isSingleLine = true }
      addView(k)
      val pv = EditText(context).apply { hint = "Picovoice AccessKey"; setText(getSharedPreferences("jarvis", 0).getString("pv", "")); isSingleLine = true }
      addView(pv)
      addView(btn("Save keys") { getSharedPreferences("jarvis", 0).edit().putString("api", k.text.toString().trim()).putString("pv", pv.text.toString().trim()).apply(); status.text = "Keys saved" })
      addView(btn("1. Enroll my voice (speak ~20 sec)") { enroll() })
      addView(btn("2. Start Jarvis (always listening)") { startForegroundService(Intent(context, JarvisService::class.java)); status.text = "Listening for 'Jarvis'" })
      addView(btn("Connect Gmail (read-only)") { connectGmail() })
      addView(btn("3. Allow phone control (Accessibility)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
      addView(btn("Stop Jarvis") { stopService(Intent(context, JarvisService::class.java)); status.text = "Stopped" })
    })
  }
  private fun connectGmail() {
    Identity.getAuthorizationClient(this).authorize(Gmail.request())
      .addOnSuccessListener { r -> if (r.hasResolution()) startIntentSenderForResult(r.pendingIntent!!.intentSender, 7, null, 0, 0, 0) else status.text = "Gmail connected" }
      .addOnFailureListener { status.text = "Gmail failed: ${it.message}" }
  }
  override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
    super.onActivityResult(rq, rs, d)
    if (rq == 7) status.text = if (rs == RESULT_OK) "Gmail connected" else "Gmail sign-in cancelled"
  }

  private fun enroll() {
    status.text = "Speak naturally now…"
    Thread {
      try {
        val p = EagleProfiler.Builder().setAccessKey(key(this)).build(this)
        val n = p.frameLength
        val rec = AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, n * 4)
        rec.startRecording(); val f = ShortArray(n); var pct = 0f
        while (pct < 100f) { rec.read(f, 0, n); pct = p.enroll(f).percentage; runOnUiThread { status.text = "Enrolling… ${pct.toInt()}%" } }
        rec.stop(); rec.release()
        File(filesDir, "profile.bin").writeBytes(p.export().bytes); p.delete()
        runOnUiThread { status.text = "Voice saved. Restart Jarvis." }
      } catch (e: Exception) { runOnUiThread { status.text = "Enroll failed: ${e.message}" } }
    }.start()
  }
}
